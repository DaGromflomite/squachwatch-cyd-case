# STL files (v20)

Every part on its own, for any slicer. All parts are already in print orientation: shells open-side up, bezels and badges face down. When your slicer asks, load each badge's parts together as **one object with multiple parts**.

| You want… | Print these |
|---|---|
| **Horizontal** (hold it sideways, USB end on the right) | `back_shell_horizontal_v20_stylus.stl` · `bezel_plain_v20_stylus.stl` · SQUACHWATCH badge: `text_bg/cyan/pink/purple_horizontal_v20_stylus.stl` · Squachy badge: the 8 `logo_<color>_v20_stylus.stl` |
| **Vertical** (hold it upright, USB cable at the bottom) | `back_shell_vertical_v20_stylus.stl` · `bezel_vertical_v20_stylus.stl` · SQUACHWATCH badge: `text_bg/cyan/pink/purple_vertical_v20_stylus.stl` · Squachy badge: the 8 `logo_<color>_v20_stylus.stl` |
| **Plain** (no graphics) | `back_shell_plain_v20_stylus.stl` · `bezel_plain_v20_stylus.stl` |

**Brim:** not needed. The project file has it turned off.

Where the badges go:
- **Horizontal:** both badges glue onto the **back** of the shell. The SQUACHWATCH badge goes above Squachy.
- **Vertical:** Squachy glues onto the back. The two-line SQUACHWATCH badge glues onto the **bezel**, under the screen.

Each badge stands 0.5 mm proud, fits its pocket only one way, and glues in with a few small drops of CA glue.

## Filament slots

| Slot | Color | Parts |
|---|---|---|
| 1 | dark grey `#2B2B2B` | shells, bezels, `text_bg` (badge background) |
| 2 | dark brown `#3A1A06` | `logo_dark_brown` |
| 3 | brown `#7A3E10` | `logo_brown` |
| 4 | black `#111111` | `logo_black` |
| 5 | teal `#16505A` | `logo_teal` |
| 6 | tan `#F0B878` | `logo_tan` |
| 7 | white `#FFFFFF` | `logo_white` |
| 8 | red `#D22323` | `logo_red` |
| 9 | purple `#B967FF` | `logo_purple`, `text_purple` |
| 10 | cyan `#00FFF5` | `text_cyan` |
| 11 | pink `#FF71CE` | `text_pink` |

Single-color printer: print the badges in one contrasting color, or skip them.
